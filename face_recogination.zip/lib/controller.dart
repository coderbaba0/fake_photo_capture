import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_ml_kit/google_ml_kit.dart';
import 'package:permission_handler/permission_handler.dart';

class FaceDetectionController extends GetxController {
  late CameraController cameraController;
  late List<CameraDescription> cameras;
  bool isDetecting = false;
  final PermissionService _permissionService = PermissionService();
  var isCameraInitialized = false.obs; // Observable to track initialization state

  @override
  void onInit() {
    super.onInit();
    requestPermissionsAndInitializeCamera();
  }

  Future<void> requestPermissionsAndInitializeCamera() async {
    bool granted = await _permissionService.requestCameraPermission();
    if (granted) {
      await initializeCamera();
    } else {
      Get.snackbar("Permission Denied", "Camera permission is required to capture images.");
    }
  }

  Future<void> initializeCamera() async {
    cameras = await availableCameras();
    cameraController = CameraController(cameras[0], ResolutionPreset.high);
    await cameraController.initialize();
    isCameraInitialized.value = true; // Set initialization state to true
    update();
  }

  Future<void> detectFaces() async {
    if (!cameraController.value.isInitialized || isDetecting) return;

    isDetecting = true;
    final frame = await cameraController.takePicture();
    final inputImage = InputImage.fromFilePath(frame.path);
    final faceDetector = GoogleMlKit.vision.faceDetector(FaceDetectorOptions(
      enableClassification: true,
      enableTracking: true,
    ));

    List<Face> faces = await faceDetector.processImage(inputImage);
    faceDetector.close();

    if (faces.isNotEmpty) {
      final face = faces[0];
      final leftEyeOpenProbability = face.leftEyeOpenProbability ?? 0.0;
      final rightEyeOpenProbability = face.rightEyeOpenProbability ?? 0.0;

      if (leftEyeOpenProbability < 0.1 && rightEyeOpenProbability < 0.1) {
        await Future.delayed(Duration(milliseconds: 200));

        List<Face> recheckFaces = await faceDetector.processImage(inputImage);
        if (recheckFaces.isNotEmpty) {
          final recheckFace = recheckFaces[0];
          final recheckLeftEyeOpenProbability = recheckFace.leftEyeOpenProbability ?? 0.0;
          final recheckRightEyeOpenProbability = recheckFace.rightEyeOpenProbability ?? 0.0;

          if (recheckLeftEyeOpenProbability > 0.9 && recheckRightEyeOpenProbability > 0.9) {
            // Face and eye blink detected, capture the picture
            captureImage();
          }
        }
      }
    }

    isDetecting = false;
  }

  Future<void> captureImage() async {
    final picture = await cameraController.takePicture();
    // Do something with the captured image
    print('Picture captured: ${picture.path}');
  }
}

class PermissionService {
  Future<bool> requestCameraPermission() async {
    final status = await Permission.camera.request();
    return status.isGranted;
  }
}
