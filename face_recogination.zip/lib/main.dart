import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'camerascreen.dart';

void main() {
  runApp(GetMaterialApp(home: CameraScreen()));
}

