import 'package:camera/camera.dart';
import 'package:face_recogination/controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class CameraScreen extends StatelessWidget {
  final FaceDetectionController faceDetectionController = Get.put(FaceDetectionController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Detect Face and Eye Blink')),
      body: Obx(() {
        if (!faceDetectionController.isCameraInitialized.value) {
          return Center(child: CircularProgressIndicator());
        }

        return Column(
          children: [
            Expanded(
              child: CameraPreview(faceDetectionController.cameraController),
            ),
            ElevatedButton(
              onPressed: () {
                if (!faceDetectionController.isDetecting) {
                  faceDetectionController.detectFaces();
                }
              },
              child: Text('Capture Image with Eye Blink Detection'),
            ),
          ],
        );
      }),
    );
  }
}
