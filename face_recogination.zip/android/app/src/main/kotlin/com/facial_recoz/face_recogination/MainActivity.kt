package com.facial_recoz.face_recogination

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
